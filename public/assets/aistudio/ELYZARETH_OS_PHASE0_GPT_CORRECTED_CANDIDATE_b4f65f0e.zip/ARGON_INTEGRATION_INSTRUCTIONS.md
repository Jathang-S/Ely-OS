# Argon Handoff — Apply GPT Phase 0 Corrective Package Exactly

You are receiving a complete repository ZIP and a unified patch. The ZIP contains the uploaded Argon candidate plus five corrected existing Kotlin files and this verification report.

## Required behaviour

1. Treat `PHASE0_CORRECTION_REPORT.md` as the scope and rationale.
2. Apply the supplied source exactly. Do not regenerate, redesign, rename, refactor, or “improve” the corrected implementation.
3. Do not change Gradle versions, dependencies, Firebase configuration, metadata, unrelated UI files, or APK files.
4. Do not advance to Phase 1, implement Room/Keystore, unlock G5, or enable Master Player.
5. If the patch conflicts with the current workspace, stop and report the exact conflicting path and current file hash. Do not resolve conflicts by inventing a new implementation.

## Files expected to change

1. `app/src/main/java/com/example/elyzareth/core/dataflow/HumanDecisionContract.kt`
2. `app/src/main/java/com/example/elyzareth/core/dataflow/ElyzarethHumanDecisionAuthority.kt`
3. `app/src/main/java/com/example/elyzareth/core/governor/GovernorContract.kt`
4. `app/src/main/java/com/example/elyzareth/core/governor/ElyzarethGovernorEngine.kt`
5. `app/src/test/java/com/example/elyzareth/core/governor/GovernorEvidenceAuthorityTest.kt`

No new Kotlin files are expected.

## Required verification in the Android project workspace

Run from the repository root:

```bash
gradle :app:compileDebugKotlin :app:testDebugUnitTest --rerun-tasks --info
```

If your workspace uses a valid Gradle wrapper, use its normal wrapper command instead. The uploaded ZIP currently lacks `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar`; do not silently fabricate or add wrapper files as part of this correction. Report if the workspace has a valid wrapper or system Gradle available.

Return:

- full command and complete terminal output;
- actual Gradle/Kotlin/AGP/JDK versions;
- exact test count and XML test reports;
- complete modified-file list and diff stat;
- confirmation that no APK was generated or overwritten;
- any test/build failure with the full first relevant stack trace.

Do not report success based only on a previous build, cached APK, static inspection, or a local harness. No commit to the canonical branch and no Phase 0 seal until GPT has independently audited the integrated result and the project owner accepts it.
